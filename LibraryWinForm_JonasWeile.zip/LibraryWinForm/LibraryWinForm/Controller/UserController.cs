﻿using LibraryWinForm.DBAccess;
using LibraryWinForm.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryWinForm.Controller {
    public class UserController {
        public void CreateUser(User user) {
            DBUser dBUser = new DBUser();
            dBUser.CreateUser(user);
        }
        public List<User> GetAllUsers() {
            DBUser dBUser = new DBUser();
            List<User> foundUsers = dBUser.GetAllUsers();
            return foundUsers;
        }
    }
}
