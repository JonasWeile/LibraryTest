﻿using LibraryWinForm.DBAccess;
using LibraryWinForm.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LibraryWinForm.Controller {
    public class BookController {

        public void CreateBook(Book book) {
            DBBook dBBook = new DBBook();
            dBBook.CreateBook(book);
        }
        public List<Book> GetAllBooks() {
            DBBook dBBook = new DBBook();
            List<Book> foundBooks = dBBook.GetAllBooks();
            return foundBooks;
        }
        public List<Book> GetAllFreeBooks() {
            DBBook dBBook = new DBBook();
            List<Book> foundFreeBooks = dBBook.GetAllFreeBooks();
            return foundFreeBooks;
        }
    }
}
