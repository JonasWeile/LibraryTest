﻿using LibraryWinForm.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryWinForm.DBAccess;

namespace LibraryWinForm.Controller {
    public class LoanController {
        public void CreateLoan(int userId, int bookId) {
            DBLoan dBLoan = new DBLoan();
            dBLoan.CreateLoan(userId, bookId);
        }
        public void ReturnBook(int bookId) {
            DBLoan dBLoan = new DBLoan();
            dBLoan.ReturnBook(bookId);
        }
    }
}
