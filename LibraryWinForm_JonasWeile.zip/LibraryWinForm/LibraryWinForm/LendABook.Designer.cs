﻿namespace LibraryWinForm {
    partial class LendABook {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.listBoxListAllBooksToLend = new System.Windows.Forms.ListBox();
            this.btnBackFromLendABook = new System.Windows.Forms.Button();
            this.lblChosenBook = new System.Windows.Forms.Label();
            this.lblUserToLendBook = new System.Windows.Forms.Label();
            this.cbListUserNames = new System.Windows.Forms.ComboBox();
            this.btnLoanTheBook = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBoxListAllBooksToLend
            // 
            this.listBoxListAllBooksToLend.FormattingEnabled = true;
            this.listBoxListAllBooksToLend.Location = new System.Drawing.Point(120, 37);
            this.listBoxListAllBooksToLend.Name = "listBoxListAllBooksToLend";
            this.listBoxListAllBooksToLend.Size = new System.Drawing.Size(550, 238);
            this.listBoxListAllBooksToLend.TabIndex = 0;
            this.listBoxListAllBooksToLend.SelectedIndexChanged += new System.EventHandler(this.listBoxListAllBooksToLend_SelectedIndexChanged);
            // 
            // btnBackFromLendABook
            // 
            this.btnBackFromLendABook.Location = new System.Drawing.Point(12, 415);
            this.btnBackFromLendABook.Name = "btnBackFromLendABook";
            this.btnBackFromLendABook.Size = new System.Drawing.Size(75, 23);
            this.btnBackFromLendABook.TabIndex = 1;
            this.btnBackFromLendABook.Text = "Back";
            this.btnBackFromLendABook.UseVisualStyleBackColor = true;
            this.btnBackFromLendABook.Click += new System.EventHandler(this.btnBackFromLendABook_Click);
            // 
            // lblChosenBook
            // 
            this.lblChosenBook.AutoSize = true;
            this.lblChosenBook.Location = new System.Drawing.Point(117, 299);
            this.lblChosenBook.Name = "lblChosenBook";
            this.lblChosenBook.Size = new System.Drawing.Size(32, 13);
            this.lblChosenBook.TabIndex = 0;
            this.lblChosenBook.Text = "Book";
            // 
            // lblUserToLendBook
            // 
            this.lblUserToLendBook.AutoSize = true;
            this.lblUserToLendBook.Location = new System.Drawing.Point(120, 331);
            this.lblUserToLendBook.Name = "lblUserToLendBook";
            this.lblUserToLendBook.Size = new System.Drawing.Size(29, 13);
            this.lblUserToLendBook.TabIndex = 2;
            this.lblUserToLendBook.Text = "User";
            // 
            // cbListUserNames
            // 
            this.cbListUserNames.FormattingEnabled = true;
            this.cbListUserNames.Location = new System.Drawing.Point(155, 328);
            this.cbListUserNames.Name = "cbListUserNames";
            this.cbListUserNames.Size = new System.Drawing.Size(181, 21);
            this.cbListUserNames.TabIndex = 3;
            // 
            // btnLoanTheBook
            // 
            this.btnLoanTheBook.Location = new System.Drawing.Point(155, 367);
            this.btnLoanTheBook.Name = "btnLoanTheBook";
            this.btnLoanTheBook.Size = new System.Drawing.Size(110, 47);
            this.btnLoanTheBook.TabIndex = 4;
            this.btnLoanTheBook.Text = "Loan the book";
            this.btnLoanTheBook.UseVisualStyleBackColor = true;
            this.btnLoanTheBook.Click += new System.EventHandler(this.btnLoanTheBook_Click);
            // 
            // LendABook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLoanTheBook);
            this.Controls.Add(this.cbListUserNames);
            this.Controls.Add(this.lblUserToLendBook);
            this.Controls.Add(this.lblChosenBook);
            this.Controls.Add(this.btnBackFromLendABook);
            this.Controls.Add(this.listBoxListAllBooksToLend);
            this.Name = "LendABook";
            this.Text = "LendABook";
            this.Load += new System.EventHandler(this.LendABook_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxListAllBooksToLend;
        private System.Windows.Forms.Button btnBackFromLendABook;
        private System.Windows.Forms.Label lblChosenBook;
        private System.Windows.Forms.Label lblUserToLendBook;
        private System.Windows.Forms.ComboBox cbListUserNames;
        private System.Windows.Forms.Button btnLoanTheBook;
    }
}