﻿using LibraryWinForm.Controller;
using LibraryWinForm.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryWinForm {
    public partial class LendABook : Form {
        public LendABook(Form form) {
            InitializeComponent();
            form.Visible = false;

        }

        private void btnBackFromLendABook_Click(object sender, EventArgs e) {
            LendABook step = new LendABook(this);
            step.Visible = false;
            Form1 form1 = new Form1();
            form1.Visible = true;
        }

        private void LendABook_Load(object sender, EventArgs e) {
            ShowAllBooks();
        }

        private void listBoxListAllBooksToLend_SelectedIndexChanged(object sender, EventArgs e) {
            Book si = listBoxListAllBooksToLend.SelectedItem as Book;


            lblChosenBook.Text ="Book selected: " + " Title: " + si.Title + " Author: " + si.Author + " ISBN: " + si.ISBN;

            cbListUserNames.Items.Clear();
            UserController uc = new UserController();
            List<User> foundUsers = uc.GetAllUsers();
            foreach(var item in foundUsers) {
                cbListUserNames.Items.Add(item);
            }
        }

        private void btnLoanTheBook_Click(object sender, EventArgs e) {
            try {
                User siu = cbListUserNames.SelectedItem as User;
                Book sib = listBoxListAllBooksToLend.SelectedItem as Book;
                         
                LoanController lc = new LoanController();
                lc.CreateLoan(siu.Id, sib.Id);
                ShowAllBooks();

            }
            catch(Exception ex) {
                throw ex;
            }
        }
        private void ShowAllBooks() {
            listBoxListAllBooksToLend.Items.Clear();

            BookController bc = new BookController();
            List<Book> foundFreeBooks = bc.GetAllFreeBooks();
            foreach (Book book in foundFreeBooks) {
                listBoxListAllBooksToLend.Items.Add(book);
            }
        }
    }
}
