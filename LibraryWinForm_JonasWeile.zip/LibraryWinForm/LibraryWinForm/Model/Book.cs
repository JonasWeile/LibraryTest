﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryWinForm.Model {
    public class Book {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string ISBN { get; set; }
        public bool Lend { get; set; }

        public Book(int id, string title, string author, string isbn) {
            Id = id;
            Title = title;
            Author = author;
            ISBN = isbn;
        }
        public Book(string title, string author, string isbn, bool lend) {
            Title = title;
            Author = author;
            ISBN = isbn;
            Lend = Lend;
        }

        public Book() {
        }

        public override string ToString() {
            string bookString = "Title: " + Title + " Author: " + Author + " ISBN: " + ISBN + " Lend: " + Lend;
            return bookString;
        }
    }
    
}
