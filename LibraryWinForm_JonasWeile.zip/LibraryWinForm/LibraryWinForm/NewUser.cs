﻿using LibraryWinForm.Controller;
using LibraryWinForm.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryWinForm {
    public partial class NewUser : Form {
        public NewUser(Form form) {
            InitializeComponent();
            form.Visible = false;
        }

        private void btnNewUser_Click(object sender, EventArgs e) {
            User user = new User(txtUsername.Text);
            UserController uc = new UserController();
            uc.CreateUser(user);
            txtUsername.Clear();
        }

        private void btnNewUserBack_Click(object sender, EventArgs e) {
            NewUser step = new NewUser(this);
            step.Visible = false;
            Form1 form1 = new Form1();
            form1.Visible = true;
        }
    }
}
