﻿namespace LibraryWinForm {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.btnNewBook = new System.Windows.Forms.Button();
            this.btnNewUser = new System.Windows.Forms.Button();
            this.btnOverview = new System.Windows.Forms.Button();
            this.btnLendABook = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnNewBook
            // 
            this.btnNewBook.Location = new System.Drawing.Point(169, 82);
            this.btnNewBook.Name = "btnNewBook";
            this.btnNewBook.Size = new System.Drawing.Size(116, 87);
            this.btnNewBook.TabIndex = 0;
            this.btnNewBook.Text = "New book";
            this.btnNewBook.UseVisualStyleBackColor = true;
            this.btnNewBook.Click += new System.EventHandler(this.btnNewBook_Click);
            // 
            // btnNewUser
            // 
            this.btnNewUser.Location = new System.Drawing.Point(441, 82);
            this.btnNewUser.Name = "btnNewUser";
            this.btnNewUser.Size = new System.Drawing.Size(116, 87);
            this.btnNewUser.TabIndex = 1;
            this.btnNewUser.Text = "New user";
            this.btnNewUser.UseVisualStyleBackColor = true;
            this.btnNewUser.Click += new System.EventHandler(this.btnNewUser_Click);
            // 
            // btnOverview
            // 
            this.btnOverview.Location = new System.Drawing.Point(441, 285);
            this.btnOverview.Name = "btnOverview";
            this.btnOverview.Size = new System.Drawing.Size(116, 87);
            this.btnOverview.TabIndex = 2;
            this.btnOverview.Text = "Overview";
            this.btnOverview.UseVisualStyleBackColor = true;
            this.btnOverview.Click += new System.EventHandler(this.btnOverview_Click);
            // 
            // btnLendABook
            // 
            this.btnLendABook.Location = new System.Drawing.Point(169, 285);
            this.btnLendABook.Name = "btnLendABook";
            this.btnLendABook.Size = new System.Drawing.Size(116, 87);
            this.btnLendABook.TabIndex = 3;
            this.btnLendABook.Text = "Lend a book";
            this.btnLendABook.UseVisualStyleBackColor = true;
            this.btnLendABook.Click += new System.EventHandler(this.btnLendABook_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLendABook);
            this.Controls.Add(this.btnOverview);
            this.Controls.Add(this.btnNewUser);
            this.Controls.Add(this.btnNewBook);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNewBook;
        private System.Windows.Forms.Button btnNewUser;
        private System.Windows.Forms.Button btnOverview;
        private System.Windows.Forms.Button btnLendABook;
    }
}

