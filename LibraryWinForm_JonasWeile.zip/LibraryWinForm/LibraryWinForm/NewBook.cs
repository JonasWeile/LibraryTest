﻿using LibraryWinForm.Controller;
using LibraryWinForm.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryWinForm {
    public partial class NewBook : Form {


        public NewBook(Form form) {
            InitializeComponent();
            form.Visible = false;
        }

        private void btnCreateNewBook_Click(object sender, EventArgs e) {
            Book book = new Book(txtTitle.Text, txtAuthor.Text, txtISBN.Text, false);
            BookController bc = new BookController();
            bc.CreateBook(book);
            txtTitle.Clear();
            txtAuthor.Clear();
            txtISBN.Clear();
        }

        private void btnNewBookBack_Click(object sender, EventArgs e) {
            NewBook step = new NewBook(this);
            step.Visible = false;
            Form1 form1 = new Form1();
            form1.Visible = true;
        }
    }
}
