﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryWinForm {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        private void btnNewBook_Click(object sender, EventArgs e) {
            NewBook step = new NewBook(this);
            step.Visible = true;
        }

        private void btnNewUser_Click(object sender, EventArgs e) {
            NewUser step = new NewUser(this);
            step.Visible = true;
        }

        private void btnOverview_Click(object sender, EventArgs e) {
            Overview step = new Overview(this);
            step.Visible = true;
        }

        private void btnLendABook_Click(object sender, EventArgs e) {
            LendABook step = new LendABook(this);
            step.Visible = true;
        }
    }
}
