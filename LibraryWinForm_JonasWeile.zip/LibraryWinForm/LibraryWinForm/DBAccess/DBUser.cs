﻿using LibraryWinForm.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryWinForm.DBAccess {
    public class DBUser {
        private string _connectionString;

        public DBUser() {
            _connectionString = ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;
        }

        public void CreateUser(User user) {
            try {
                using (SqlConnection connection = new SqlConnection(_connectionString)) {
                    connection.Open();

                    using (SqlCommand cmdInsertFood = connection.CreateCommand()) {
                        cmdInsertFood.CommandText = "INSERT INTO LibraryUser(Name) VALUES(@Name)";
                        cmdInsertFood.Parameters.AddWithValue("Name", user.Name);
                        cmdInsertFood.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex) {
                throw ex;
            }
        }
            public List<User> GetAllUsers() {
                List<User> users = new List<User>();
                User tempU;

                try {
                    using (SqlConnection connection = new SqlConnection(_connectionString)) {
                        connection.Open();

                        using (SqlCommand cmdGetAllUsers = connection.CreateCommand()) {
                            cmdGetAllUsers.CommandText = "select Id, Name from LibraryUser";
                            SqlDataReader reader = cmdGetAllUsers.ExecuteReader();

                            while (reader.Read()) {
                                tempU = new User();
                                tempU.Id = reader.GetInt32(reader.GetOrdinal("Id"));
                                tempU.Name = reader.GetString(reader.GetOrdinal("Name"));
                                users.Add(tempU);
                            }
                        }
                    }
                }
                catch (SqlException ex) {
                    throw ex;
                }
                return users;
            }
        }
    }

