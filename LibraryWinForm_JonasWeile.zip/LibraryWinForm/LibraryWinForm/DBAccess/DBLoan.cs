﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Transactions;
using LibraryWinForm.Model;

namespace LibraryWinForm.DBAccess {
    public class DBLoan {
        private string _connectionString;

        public DBLoan() {
            _connectionString = ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;
        }

        public void CreateLoan(int userId, int bookId) {

            try {
                using (SqlConnection connection = new SqlConnection(_connectionString)) {
                    connection.Open();

                    using (SqlCommand cmdCreateLoan = connection.CreateCommand()) {
                        cmdCreateLoan.Parameters.AddWithValue("UserId", userId);
                        cmdCreateLoan.Parameters.AddWithValue("BookId", bookId);
                        cmdCreateLoan.Parameters.AddWithValue("Lend", true);
                        cmdCreateLoan.CommandText = "INSERT INTO UserBook(UserId, BookId) VALUES(@UserId, @BookId)";
                        cmdCreateLoan.CommandText = "update Book set Lend = @Lend where id = @BookId";
                        cmdCreateLoan.ExecuteNonQuery();

                    }
                }
            }
            catch (SqlException ex) {
                throw ex;
            }
        }
        public void ReturnBook(int bookId) {

            try {
                using (SqlConnection connection = new SqlConnection(_connectionString)) {
                    connection.Open();

                    using (SqlCommand cmdCreateLoan = connection.CreateCommand()) {
                        cmdCreateLoan.Parameters.AddWithValue("BookId", bookId);
                        cmdCreateLoan.Parameters.AddWithValue("Lend", false);
                        cmdCreateLoan.CommandText = "delete from UserBook(BookId) where VALUES(@BookId)";
                        cmdCreateLoan.CommandText = "update Book set Lend = @Lend where id = @BookId";
                        cmdCreateLoan.ExecuteNonQuery();

                    }
                }
            }
            catch (SqlException ex) {
                throw ex;
            }
        }

    }
}
