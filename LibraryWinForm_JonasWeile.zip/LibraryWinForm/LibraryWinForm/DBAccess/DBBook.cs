﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Transactions;
using LibraryWinForm.Model;

namespace LibraryWinForm.DBAccess {
    public class DBBook {
        private string _connectionString;
        
        public DBBook() {
            _connectionString = ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;
        }

        public void CreateBook(Book book) {
            try {
                using (SqlConnection connection = new SqlConnection(_connectionString)) {
                    connection.Open();

                    using (SqlCommand cmdInsertFood = connection.CreateCommand()) {
                        cmdInsertFood.CommandText = "INSERT INTO Book(Title, Author, ISBN, Lend) VALUES(@Title, @Author, @ISBN, @Lend)";
                        cmdInsertFood.Parameters.AddWithValue("Title", book.Title);
                        cmdInsertFood.Parameters.AddWithValue("Author", book.Author);
                        cmdInsertFood.Parameters.AddWithValue("ISBN", book.ISBN);
                        cmdInsertFood.Parameters.AddWithValue("Lend", book.Lend);
                        cmdInsertFood.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex) {
                throw ex;
            }
        }

      

        public List<Book> GetAllBooks() {
            List<Book> books = new List<Book>();
            Book tempB;

            try {
                using (SqlConnection connection = new SqlConnection(_connectionString)) {
                    connection.Open();

                    using (SqlCommand cmdGetAllBooks = connection.CreateCommand()) {
                        cmdGetAllBooks.CommandText = "select Id, Title, Author, ISBN, Lend from Book";
                        SqlDataReader reader = cmdGetAllBooks.ExecuteReader();

                        while (reader.Read()) {
                            tempB = new Book();
                            tempB.Id = reader.GetInt32(reader.GetOrdinal("Id"));
                            tempB.Title = reader.GetString(reader.GetOrdinal("Title"));
                            tempB.Author = reader.GetString(reader.GetOrdinal("Author"));
                            tempB.ISBN = reader.GetString(reader.GetOrdinal("ISBN"));
                            tempB.Lend = reader.GetBoolean(reader.GetOrdinal("Lend"));
                            books.Add(tempB);
                        }
                    }
                }
            }
            catch (SqlException ex) {
                throw ex;
            }
            return books;
        }
        public List<Book> GetAllFreeBooks() {
            List<Book> books = new List<Book>();
            Book tempB;

            try {
                using (SqlConnection connection = new SqlConnection(_connectionString)) {
                    connection.Open();

                    using (SqlCommand cmdGetAllBooks = connection.CreateCommand()) {
                        cmdGetAllBooks.CommandText = "select Id, Title, Author, ISBN from Book where Lend = 'false'";
                        SqlDataReader reader = cmdGetAllBooks.ExecuteReader();

                        while (reader.Read()) {
                            tempB = new Book();
                            tempB.Id = reader.GetInt32(reader.GetOrdinal("Id"));
                            tempB.Title = reader.GetString(reader.GetOrdinal("Title"));
                            tempB.Author = reader.GetString(reader.GetOrdinal("Author"));
                            tempB.ISBN = reader.GetString(reader.GetOrdinal("ISBN"));
                            books.Add(tempB);
                        }
                    }
                }
            }
            catch (SqlException ex) {
                throw ex;
            }
            return books;
        }
    }
}
