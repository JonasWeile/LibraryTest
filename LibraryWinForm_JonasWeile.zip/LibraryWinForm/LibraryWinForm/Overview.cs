﻿using LibraryWinForm.Controller;
using LibraryWinForm.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryWinForm {
    public partial class Overview : Form {
        public Overview(Form form) {
            InitializeComponent();
            form.Visible = false;
        }

        private void btnOverviewBack_Click(object sender, EventArgs e) {
            NewUser step = new NewUser(this);
            step.Visible = false;
            Form1 form1 = new Form1();
            form1.Visible = true;
        }

        private void Overview_Load(object sender, EventArgs e) {
            ShowAllBooks();
            UserController uc = new UserController();
            List<User> foundUsers = uc.GetAllUsers();
            foreach(User user in foundUsers) {
                listBoxAllUsers.Items.Add(user);
            }

        }

        private void listShowAllBooks_SelectedIndexChanged(object sender, EventArgs e) {
            Book si = listShowAllBooks.SelectedItem as Book;

            lblReturnSelectedBook.Text = "Book selected: " + " Title: " + si.Title + " Author: " + si.Author + " ISBN: " + si.ISBN;
        }

        private void btnReturnSelectedBook_Click(object sender, EventArgs e) {
            Book sib = listShowAllBooks.SelectedItem as Book;

            LoanController lc = new LoanController();
            lc.ReturnBook(sib.Id);
           
            ShowAllBooks();
        }

        private void ShowAllBooks() {
            listShowAllBooks.Items.Clear();
            BookController bc = new BookController();
            List<Book> foundBooks = bc.GetAllBooks();
            foreach (Book book in foundBooks) {
                listShowAllBooks.Items.Add(book);
            }
        }
    }
}
